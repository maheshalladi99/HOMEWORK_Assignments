package com.spring.mvc.model;

public class User {

}
